// global.js
document.addEventListener("keydown", function (e) {
  if (e.key.toLowerCase() === "q") {
    window.location.href = "https://www.instructure.com/canvas/login";
  }
});
